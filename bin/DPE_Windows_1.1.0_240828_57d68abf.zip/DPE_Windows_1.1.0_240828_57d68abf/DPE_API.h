/**
 * @file 
 * API c++ for DPE (Data Processing Engine). 
 * Copyright (C) 2022 Lukas Marek
 * @author  Lukas Marek <lukas.marek@advacam.cz>
 */

#ifndef DPEAPI_H
#define DPEAPI_H

#include <stdio.h> 
#include <stdlib.h> 
#include <vector>
#include <string>
#include <map>

// #ifndef WIN32
//     #define DPEAPI __attribute__ ((visibility("default")))
// #else
//     #define DPEAPI __declspec(dllexport)
// #endif

#ifdef _WIN64
    #define DPEAPI __declspec(dllexport)
#else
    #define DPEAPI 
#endif

// Error Codes:
#define DPE_ERR_NO_ERR              0           ///< No error occurred.
#define DPE_ERR_NO_DATA_POSTPROC    -10         ///< No data for data post processing.

// Cluster variables names
#define CLVAR_DETECTOR_ID       "DetectorID"
#define CLVAR_EVENT_ID          "EventID"
#define CLVAR_X                 "X"
#define CLVAR_Y                 "Y"
#define CLVAR_TIME              "T"
#define CLVAR_FLAGS             "Flags"
#define CLVAR_SIZE              "Size"
#define CLVAR_ENERGY            "E"
#define CLVAR_HEIGHT            "Height"
#define CLVAR_BORDER_PIX_N      "BorderPixCount"
#define CLVAR_ROUND             "Roundness"
#define CLVAR_LIN               "Linearity"
#define CLVAR_ANGLE_AZIM        "AngleAzim"
#define CLVAR_LENGHT_PROJ       "LengthProj" 
#define CLVAR_WIDTH_PROJ        "WidthProj"
#define CLVAR_IS_SENSE_EDGE     "IsSensEdge"
#define CLVAR_STD_PERP          "StdPerp"
#define CLVAR_STD_ALONG         "StdAlong"          
#define CLVAR_THIN              "Thin"
#define CLVAR_THICK             "Thick"
#define CLVAR_CURLYTHIN         "CurlyThin"
#define CLVAR_EPIX_MEAN         "EpixMean"
#define CLVAR_EPIX_STD          "EpixStd"
#define CLVAR_LENGTH_CORR_STD   "LengthCorrStd"
#define CLVAR_WIDTH_CORR_STD    "Length3DCorrStd"
#define CLVAR_ANGLE_ELEV        "AngleElev"
#define CLVAR_LET               "LET"
#define CLVAR_DIAMETER          "Diameter"
#define CLVAR_PID               "PIDClass"         
#define CLVAR_CLUSTER_ID        "ClusterID"
#define CLVAR_CLUSTER_PIXELS    "ClusterPixels"

namespace dpe
{

/// Construct DPE at the beginning of processing.
/// @return 0 if OK, otherwise error code.
DPEAPI int construct();

/// Destruc DPE at the end of processing.
/// @return 0 if OK, otherwise error code.
DPEAPI int destruct();

/// Load file with parameters of DPE.
/// @param FileParam_Path full path to file with parameters.
/// @param FileParam_Name name of file with parameters.
/// @return 0 if OK, otherwise error code.
DPEAPI int loadParamFile(std::string FileParam_Path="./", std::string FileParam_Name="ParamFile.txt");

/// Set order of cluster variable names as they will be given in the cluster add.
/// It has to be used before init as part of DPE general setting or load of param. file.
/// @param  ClusterVarNames names of cluster variables in intended order for cluster add
///         function. Names of cluster variables should be taken from macros (CLVAR_...)
///         Example: ClusterVarNames = {CLVAR_DETECTOR_ID, CLVAR_EVENT_ID, CLVAR_SIZE}.
///         If not used before init or empty vector given, default order is used as listed:
///         CLVAR_DETECTOR_ID, CLVAR_EVENT_ID, CLVAR_X, CLVAR_Y, CLVAR_TIME, CLVAR_FLAGS,
///         CLVAR_SIZE, CLVAR_ENERGY, CLVAR_HEIGHT, CLVAR_BORDER_PIX_N, CLVAR_ROUND, CLVAR_LIN,
///         CLVAR_ANGLE, CLVAR_LENGHT, CLVAR_WIDTH.
/// @return 0 if OK, otherwise error code.
DPEAPI int setClusterVarOrder(std::vector<std::string> ClusterVarNames = {});

/// Init DPE after setting its parameters. It is mainly for modules initialization
/// and propagation of parameters into them. Export directories are also created (if needed).
/// @return 0 if OK, otherwise error code.
DPEAPI int init();

/// Reset DPE data storage and physical products (includes mainly reset of modules).
/// Settings remains the same as set with the parameters file or individual sets.
/// @return 0 if OK, otherwise error code.
DPEAPI int reset();

/// Reset DPE current data storage (sets them to 0). The total and other storage are not influenced.
/// If the storage should be reset between cluster processing then this function should be called 
/// between them (ProcessClusters(); ResetCurrDataStorage(); ;ProcessClusters();)  
/// @return 0 if OK, otherwise error code.
DPEAPI int resetCurrDataStorage();

/// Process given clustersAddClusters. This includes also calculation of 
/// physical products as dose, flux etc. Clusters are after processing deleted from DPE to avoid
/// several processing of the same data.
/// @param Clusters vector of vectors with cluster variables which should be processed. Inner
///        vectors include variables of clusters in order given by function SetClusterVarOrder.
/// @see SetClusterVarOrder
/// @return 0 if OK, otherwise error code.
DPEAPI int processClusters(std::vector<std::vector<double> > Clusters);

/// Process data file. If input parameters are not set then the function uses
/// values given in the parameters file (if loaded).
/// @param FileIn_Path full path to the data file.
/// @param FileIn_Name name of the data file.d
/// @param FileIn_NameEnd name end (e.g. extension ".txt") of the data file. 
/// @return 0 if OK, otherwise error code.
DPEAPI int processFile(std::string FileIn_Path = "", std::string FileIn_Name = "", std::string FileIn_NameEnd = "");

/// Recognition of radiation field with distance comparator and significant vectors. 
/// @param Name of the recognized radiation field (e.g. Cs137).
/// @param Prob probability of recognition success.
/// @return 0 if OK, otherwise error code.
DPEAPI int radFieldRecognition(std::string& Name, double& Prob );


/// Retrieves full version of core.
/// @return string with VERSION_DATE_GITHASH or empty string if fail.
DPEAPI std::string version();


/// Sets path for input data.
/// @return 0 if OK, otherwise error code.
DPEAPI int setFileInPath(std::string FileInPath);

/// Sets names of input files with data. One or more can be used.
/// @return 0 if OK, otherwise error code.
DPEAPI int setFileInNames(std::vector<std::string> FileInNames);
 
/// Sets path for resutls.
/// @return 0 if OK, otherwise error code.
DPEAPI int setFileOutPath(std::string FileOutPath);

/// Sets time sampling.
/// @param  TimeSampling sampling time which defines a sample evaluation.
///         Its unit is in seconds. Defaults value is 1 second.
/// @return 0 if OK, otherwise error code.
DPEAPI int setTimeSampling(double TimeSampling);

/// Sets time acquisition.
/// @param  TimeAcquisition acquisition time which is used for calculation
///         of physical products. Default is set during processing based on 
///         given data.
/// @return 0 if OK, otherwise error code.
DPEAPI int setTimeAcquisition(double TimeAcquisition);

/// Sets Compton camera distance for projection.
/// @param  ProjectionDist in which projection is calculated. It is in mm.
/// @return 0 if OK, otherwise error code.
DPEAPI int setComCamProjectionDist(double ProjectionDist);

/// Sets to do export of clist.
/// @return 0 if OK, otherwise error code.
DPEAPI int setDoExportClist(bool DoExportClist);

/// Sets control to export graphics.
/// @return 0 if OK, otherwise error code.
DPEAPI int setDoExportGraphics(bool DoExportGraphics);

/// Sets control to do logging.
/// @return 0 if OK, otherwise error code.
DPEAPI int setDoLog(bool DoLog);

/// Sets control to do logging.
/// @return 0 if OK, otherwise error code.
DPEAPI int setDoPrint(bool DoPrint);

/// Sets path to the model directory.
/// @return 0 if OK, otherwise error code.
DPEAPI int setModelPath(std::string modelPath);

/// Retrieves test projection results from Compton camera directional analysis.
/// @param  Projection is an image defined in config file of Compton cam.
///         It includes back projection of Compton cones.
/// @return 0 if OK, otherwise error code.
DPEAPI int getComCamTestProjection(std::vector<double>& Projection);

/// Retrieves projection results from Compton camera directional analysis.
/// @param  Projection is an image defined in config file of Compton cam.
///         It includes back projection of Compton cones.
/// @return 0 if OK, otherwise error code.
DPEAPI int getComCamProjection(std::vector<double>& Projection);

/// Gets PID class names.
/// @return vector of class names or empty vector in the case of invalid settings (PID is turned off).
DPEAPI std::vector<std::string> getPIDClassNames();

/// Gets elapsed time for each sample.
/// @return vector of times or empty vector in the case of error.
DPEAPI std::vector<double> getElapsedTimes();

/// Gets current deposited energy.
/// @param  EnergyDep sum of deposited energy is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentEnergyDep(double& EnergyDep);

/// Gets current dose.
/// @param  Dose sum of dose is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentDose(double& Dose);

/// Gets current dose rate.
/// @param  DoseRate mean of dose rate is stored there.
/// @param  Time used for calculation.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentDoseRate(double& DoseRate, double Time = 0);

/// Gets current count of particles.
/// @param  CountParticle sum of count of particles is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentCountParticle(double& CountParticle);

/// Gets current count of rate of particles for time sample.
/// @param  CountRate mean of count rate is stored there.
/// @param  Time used for calculation.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentCountRate(double& CountRate, double Time = 0);

/// Gets current fluence.
/// @param  Fluence sum of fluence is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentFluence(double& Fluence);

/// Gets current flux.
/// @param  Flux sum of flux is stored there.
/// @param  Time used for calculation.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentFlux(double& Flux, double Time = 0);


/// Gets current deposited energy for individual particle classes.
/// @param  EnergyDepClass sum of deposited energy for individual particle classes is 
/// stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentEnergyDepClass(std::vector<double>& EnergyDepClass);

/// Gets current dose for individual particle classes.
/// @param  DoseClass sum of dose for individual particle classes is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentDoseClass(std::vector<double>& DoseClass);

/// Gets current dose rate for individual particle classes.
/// @param  DoseRateClass mean of dose rate for individual particle classes is stored 
/// there.
/// @param  Time used for calculation.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentDoseRateClass(std::vector<double>& DoseRateClass, double Time = 0);

/// Gets current count of particles for individual particle classes.
/// @param  CountParticleClass sum of count of particles for individual particle classes 
/// is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentCountParticleClass(std::vector<double>& CountParticleClass);

/// Gets current count of rate of particles for time sample.
/// @param  CountRateClass mean of count rate for individual particle classes is stored 
/// there.
/// @param  Time used for calculation for individual particle classes.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentCountRateClass(std::vector<double>& CountRateClass, double Time = 0);

/// Gets current fluence for individual particle classes.
/// @param  FluenceClass sum of fluence for individual particle classes is stored there.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentFluenceClass(std::vector<double>& FluenceClass);

/// Gets current flux for individual particle classes.
/// @param  FluxClass sum of flux for individual particle classes is stored there.
/// @param  Time used for calculation.
/// @return 0 if OK, otherwise error code.
DPEAPI int getCurrentFluxClass(std::vector<double>& FluxClass, double Time = 0);


/// Gets deposited energy.
/// @return  EnergyDep sum of deposited energy is stored there.
DPEAPI double getEnergyDep();

/// Gets dose.
/// @return  Dose sum of dose is stored there.
DPEAPI double getDose();

/// Gets dose rate.
/// @return  DoseRate mean of dose rate is stored there.
DPEAPI double getDoseRate();

/// Gets count of particles.
/// @return  CountParticle sum of count of particles is stored there.
DPEAPI double getCountParticle();

/// Gets count of rate of particles for time sample.
/// @return  CountRate mean of count rate is stored there.
DPEAPI double getCountRate();

/// Gets fluence.
/// @return  Fluence sum of fluence is stored there.
DPEAPI double getFluence();

/// Gets flux.
/// @return  Flux vector sum of flux is stored there.
DPEAPI double getFlux();


/// Gets deposited energy for time sample.
/// @return  EnergyDepTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getEnergyDepTime();

/// Gets dose for time sample.
/// @return  DoseTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getDoseTime();

/// Gets dose rate for time sample.
/// @return  DoseRateTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getDoseRateTime();

/// Gets count of particles for time sample.
/// @return  CountParticleTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getCountParticleTime();

/// Gets count of rate of particles for time sample.
/// @return  CountRateTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getCountRateTime();

/// Gets fluence of particles for time sample.
/// @return  FluenceTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getFluenceTime();

/// Gets flux for time sample.
/// @return  FluxTime vector is over time samples (based on time sapling and elapsed time).
///         Example: {TimeSample1, TimeSample2,...}
DPEAPI std::vector<double> getFluxTime();

/// Gets deposited energy for time sample and class.
/// @param  EnergyDepTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getEnergyDepTimeClass();

/// Gets dose for time sample and class.
/// @param  DoseTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getDoseTimeClass();

/// Gets dose rate for time sample and class.
/// @param  DoseRateTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getDoseRateTimeClass();

/// Gets count of particles for time sample and class.
/// @param  CountParticleTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getCountParticleTimeClass();

/// Gets count of rate of particles for time sample and class.
/// @param  CountRateTimeClass iouter vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getCountRateTimeClass();

/// Gets fluence of particles for time sample and class.
/// @param  FluenceTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getFluenceTimeClass();

/// Gets flux for time sample and class.
/// @param  FluxTimeClass outer vector is over particle classes and the inner
///         is over time samples (based on time sapling and elapsed time).
///         Example: {Class1={TimeSample1, TimeSample2, ...}, Class2=TimeSample1, TimeSample2, ...},...}
/// @return vector with the values or empty if error.
DPEAPI std::vector<std::vector<double> > getFluxTimeClass();

/// Gets Compton camera count of bins on X and Y axis for its projection.
/// @param  ComCamProjNBinX is count of bins on X axis.
/// @param  ComCamProjNBinY is count of bins on Y axis.
/// @return 0 if OK, otherwise error code.
DPEAPI int getComCamProjectionNBins(int& ComCamProjNBinX, int& ComCamProjNBinY);

/// Gets Compton camera maximum value in its projection.
/// @param  ComCamProjNBinX maximum value.
/// @return 0 if OK, otherwise error code.
DPEAPI int getComCamProjectionMaxVal(double& MaxVal);


/// Gets 1d histogram of some cluster variable of all particles.
/// @param  HistVarName name of histogram variable (see list above with CLVAR_*).
/// @return vec of vec with bin contents and low edges of bins.
///         vec[0] - bin low edges, size = bin_count + 2, From Xmin to Xmax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[1] - bin contents, size = bin_count + 2, Underflow - BinCont (bin_count) - Overflow.
///         if error occurs, then empty vector is returned.
DPEAPI std::vector<std::vector<double>> getHist1DAll(std::string HistVarName);


/// Gets 2d histogram of some cluster variable of all particles.
/// @param  HistVarName name of histogram variable (see list above with CLVAR_*).
/// @return vec of vec with bin contents and low edges of bins.
///         vec[0] - bin low edges X, size = bin_count + 2, From Xmin to Xmax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[1] - bin low edges Y, size = bin_count + 2, From Ymin to Ymax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[2] - bin contents, size = bin_count + 2, Underflow - BinCont (bin_count) - Overflow.
///         if error occurs, then empty vector is returned.
DPEAPI std::vector<std::vector<double>> getHist2DAll(std::vector<std::string> HistVarNames);

/// Gets sensor matrix with integrated deposited energy from all particles.
/// @return vec of vec with bin contents and low edges of bins.
///         vec[0] - bin low edges X, size = bin_count + 2, From Xmin to Xmax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[1] - bin low edges Y, size = bin_count + 2, From Ymin to Ymax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[2] - bin contents, size = bin_count + 2, Underflow - BinCont (bin_count) - Overflow.
///         if error occurs, then empty vector is returned.
DPEAPI std::vector<std::vector<double>> sensMatrixInt();

/// Gets sensor matrix with integrated deposited energy from sample of particles (e.g. 100 of particles).
/// @return vec of vec with bin contents and low edges of bins.
///         vec[0] - bin low edges X, size = bin_count + 2, From Xmin to Xmax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[1] - bin low edges Y, size = bin_count + 2, From Ymin to Ymax (Xmax included for overflow and Xmin 2 times for underflow).
///         vec[2] - bin contents, size = bin_count + 2, Underflow - BinCont (bin_count) - Overflow.
///         if error occurs, then empty vector is returned.
DPEAPI std::vector<std::vector<double>> sensMatrixSample();


/// Gets path for the input data.
/// @return file in path, empty string signals error.
DPEAPI std::string getFileInPath();

/// Gets value of sampling time.
/// @return value of sampling time, zero/negative value signals error.
DPEAPI double getSamplingTime();

/// Gets path to exported data.
/// @return file out path, empty string signals error.
DPEAPI std::string getFileOutPath();

/// Gets check whether clist should be exported.
/// @return check whether clist should be exported.
DPEAPI bool getDoExportClist();


/// Prints basic settings of DPE.
/// @return if error occurs, then apropriet error code is returned.
DPEAPI int print();

}

#endif /* !DPEAPI_H */
