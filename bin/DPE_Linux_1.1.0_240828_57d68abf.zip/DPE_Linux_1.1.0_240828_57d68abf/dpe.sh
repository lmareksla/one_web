#!/bin/bash

SCRIPT_DIR="$( cd -- "$( dirname -- "${BASH_SOURCE[0]:-$0}"; )" &> /dev/null && pwd 2> /dev/null; )";
export LD_LIBRARY_PATH=$SCRIPT_DIR/
$SCRIPT_DIR/DPE $1